#ifndef __PCAP04_DEFINES_H_
#define __PCAP04_DEFINES_H_

#include "pcap04_types.h"
#include "pcap04_registers.h"

  // OP Codes
  //pcap_opcode_nvram_t wr_mem = {.nvram = {.data = 0, .addr = 0, .op_code = WR_NVRAM}};
  //pcap_opcode_nvram_t rd_mem = {.nvram = {.data = 0, .addr = 0, .op_code = RD_NVRAM}};

  //pcap_opcode_config_t wr_config = {.config = {.data = 0, .addr = 0, .op_code = WR_CONFIG}};
  //pcap_opcode_config_t rd_config = {.config = {.data = 0, .addr = 0, .op_code = RD_CONFIG}};

  //pcap_opcode_result_t rd_result = {.result = {.data = 0, .addr = 0, .op_code = RD_RESULT}};

  //pcap_opcode_command_t por_reset = {.command = {.op_code = POR_RESET}};
  //pcap_opcode_command_t initialize_op = {.command = {.op_code = INITIALIZE_OP}};
  //pcap_opcode_command_t cdc_start = {.command = {.op_code = CDC_START}};
  //pcap_opcode_command_t rdc_start = {.command = {.op_code = RDC_START}};
  //pcap_opcode_command_t dsp_trig = {.command = {.op_code = DSP_TRIG}};
  //pcap_opcode_command_t nv_store = {.command = {.op_code = NV_STORE}};
  //pcap_opcode_command_t nv_recall = {.command = {.op_code = NV_RECALL}};
  //pcap_opcode_command_t nv_erase = {.command = {.op_code = NV_ERASE}};
  //pcap_opcode_testread_t test_read = {.testread = {.fixed = TEST_READ_LOW, .op_code = TEST_READ_HIGH}};

#endif /* __PCAP04_DEFINES_H_ */
